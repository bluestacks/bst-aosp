# Copyright (C) 2011-2014 The Android-x86 Open Source Project

LOCAL_PATH := $(call my-dir)

# HAL module implemenation, not prelinked and stored in
# hw/<OVERLAY_HARDWARE_MODULE_ID>.<ro.product.board>.so
include $(CLEAR_VARS)
LOCAL_SHARED_LIBRARIES := liblog libcutils
LOCAL_MODULE_TAGS := optional
LOCAL_SRC_FILES := lights.c
LOCAL_MODULE := lights.bst
LOCAL_MODULE_RELATIVE_PATH := hw
LOCAL_C_INCLUDES += \
    hardware/libhardware/include_vendor

include $(BUILD_SHARED_LIBRARY)
